  _______                    __   ___           __          __  _       _____ _______ _____ 
 |__   __|                   \ \ / (_)          \ \        / / | |     |  __ \__   __/ ____|
    | | ___  __ _ _ __ ___    \ V / _   ______   \ \  /\  / /__| |__   | |__) | | | | (___  
    | |/ _ \/ _` | '_ ` _ \    > < | | |______|   \ \/  \/ / _ \ '_ \  |  _  /  | |  \___ \ 
    | |  __/ (_| | | | | | |  / . \| |             \  /\  /  __/ |_) | | | \ \  | |  ____) |
    |_|\___|\__,_|_| |_| |_| /_/ \_\_|              \/  \/ \___|_.__/  |_|  \_\ |_| |_____/ 

                        Oregon State University - Summer 2016
                              CS 419 - Software Projects

                      Brandon Gipson - Graphics & Engine Developer
                               James Pool - AI Developer
                        Tom Dale - Units and Balance Developer

Aggregate Version: 0a
Start Date: 15 July 2016

This is a combination of the work produced up unitl this point with the goal of
providing a snapshot of the overall project status.